// File:    BFNetwork.h
//

#if !defined (BFNETWORK_H)
#define BFNETWORK_H

#include <afxsock.h>

CString getServerIP();

#endif

