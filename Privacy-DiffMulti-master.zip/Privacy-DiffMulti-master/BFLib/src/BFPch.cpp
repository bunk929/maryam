// BFPch.cpp : source file that includes just the standard includes
//	BFLib.pch will be the pre-compiled header
//	BFPch.obj will contain the pre-compiled type information

#include "BFPch.h"

